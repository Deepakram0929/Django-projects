# **Simple Banking Management System in Python using Django Framework **
==============================================================================================
## **Admin Access**
- **Email:** admin@mail.com
- **Password:** admin123

## **User Access**
- **Email:** dhanush@mail.com
- **Password:** Deepak@123
==============================================================================================

============================================================================
**Instructions**
- Install the Requirements: pip install -r requirements.txt
- python manage.py migrate
- And finally, run the application: python manage.py runserver
============================================================================
python -m venev myenv
myenv\Scripts\activate
python manage.py runserver


# curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py

# get-pip.py
# 